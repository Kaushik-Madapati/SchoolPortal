var express = require('express');
var router = express.Router();


var mongoose = require('mongoose');

mongoose.set('debug', true);
//var db = mongojs('mongodb://brad:brad@ds047666.mlab.com:47666/mytasklist_brad', ['tasks']);

mongoose.connect('mongodb://ec2-34-215-100-184.us-west-2.compute.amazonaws.com:27017/test');

var UserInfo     = require('../server/models/user_info');

// middleware to use for all requests
router.use(function(req, res, next) {
    // do logging
    console.log('Something is happening.');
    next(); // make sure we go to the next routes and don't stop here
});





router.route('/users')

	// create a bear (accessed at POST http://localhost:8080/users)
	.post(function(req, res) {
		
		var userInfo = new UserInfo();		// create a new instance of the Bear model
		userInfo.name = req.body.name;  // set the bears name (comes from the request)
		userInfo.email = req.body.email;
		userInfo.description = res.body.description;

		res.setHeader('Access-Control-Allow-Origin', '*');

		userInfo.save(function(err) {
			if (err) {
				res.send(err);
			    return ; 
			}

			res.json({ message: 'user info  created!' });
		});

		
	})
	.get(function(req, res) {
        UserInfo.find(function(err, users) {
            if (err)
                res.send(err);

            res.json(users);
        });
    });



module.exports = router;